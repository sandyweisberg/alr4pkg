## R CMD check results

## Test environments
* local OS X install, R 4.3.1
* win-builder (devel and release)

## R CMD check results
There were no ERRORs or WARNINGs or NOTEs


## Reverse dependencies
There are 4 reverse dependencies. I have run `revdepcheck::revdep_check()`.
All 4 packages passed with no new failures.

##
I have run R-hub with no errors

This release removes defunt urls from documentation, and fixed syntax in 
DESCRIPTION

